﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DBContext;
using DBEntity;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
//using System.Web.Http;

namespace UPC.APIBusiness.API.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Produces("application/json")]
    [Route("api/data")]
    [ApiController]
    public class JsonController : Controller
    //public class JsonController : ApiController
    {
        /// <summary>
        /// 
        /// </summary>
        protected readonly IRepository repository;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="projectRepository"></param>
        public JsonController(IRepository irepository)
        {
            repository = irepository;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [Produces("application/json")]
        [Consumes("application/json")]
        [AllowAnonymous]
        [HttpPost]
        [Route("go")]
        public ActionResult go([FromBody] EntityRequest entityRequest)
        {
            string jsonData = JsonSerializer.Serialize(entityRequest);
            Console.WriteLine(">>>"+ jsonData);

            var ret = repository.data(jsonData);
            string data = (string)ret.data;

            Console.WriteLine(data);
            return Content(data);
        }

    }
}

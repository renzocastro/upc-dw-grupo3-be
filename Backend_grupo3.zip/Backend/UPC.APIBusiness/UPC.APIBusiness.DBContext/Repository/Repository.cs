﻿using System;
using DBEntity;
using Dapper;
using System.Data;
using System.Linq;
using System.Collections.Generic;

namespace DBContext
{
    public class Repository : BaseRepository, IRepository
    {
        public ResponseBase data(string jsonData)
        {
            var response = new ResponseBase();

            try
            {
                using (var db = GetSqlConnection())
                {
                    Console.WriteLine("Repository:jsonData>>" + jsonData);
                    var entity = new Entity();
                    //const string sql = "usp_Listar_Departamentos_X_Proyecto";
                    string sql = "select dbo.usp_process('" + jsonData + "') as result";
                    Console.WriteLine("sql:" + sql);

                    entity = db.Query<Entity>(sql: sql
                        //, param: p
                        , commandType: CommandType.Text//StoredProcedure
                        ).FirstOrDefault();

                    Console.WriteLine("entity:" + entity);
                    if (entity != null)
                    {

                        response.isSuccess = true;
                        response.errorCode = "0000";
                        response.errorMessage = string.Empty;
                        response.data = "{ \"isSuccess\":true, \"errorCode\":\"0000\",\"data\":" + entity.result + "}";
                        Console.WriteLine("entity:" + entity.result);
                    }
                    else
                    {
                        response.isSuccess = false;
                        response.errorCode = "0000";
                        response.errorMessage = string.Empty;
                        response.data = entity;
                    }

                }
            }
            catch (Exception ep)
            {
                
                Console.WriteLine("Repository:jsonData:" + ep.Message);
                response.isSuccess = true;
                response.errorCode = "0000";
                response.errorMessage = string.Empty;
                response.data = null;
            }

            return response;
        }


    }
}

﻿using System;
using DBEntity;

namespace DBContext
{
    public interface IRepository
    {
        ResponseBase data(String jsonData);
    }
}

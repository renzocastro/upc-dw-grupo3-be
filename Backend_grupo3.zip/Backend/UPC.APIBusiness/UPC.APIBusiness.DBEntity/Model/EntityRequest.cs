﻿using System;
using System.Collections.Generic;

namespace DBEntity
{
    public class EntityRequest
    {
        public string operacion { get; set; }

        /*
         OPERACION: select
         */
        public string tabla { get; set; }

        public string insertData { get; set; }

        /*
         OPERACION: login
         */
        public string username { get; set; }
        public string pasword { get; set; }
    }
}
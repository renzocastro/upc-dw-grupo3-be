﻿using System;
using System.Collections.Generic;

namespace DBEntity
{
    public class Entity : EntityBase
    {
        public string result { get; set; }
    }
}
